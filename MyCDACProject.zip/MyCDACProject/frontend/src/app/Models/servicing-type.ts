export class ServicingType {
    
    type:string
    price:number
    time:number
}
