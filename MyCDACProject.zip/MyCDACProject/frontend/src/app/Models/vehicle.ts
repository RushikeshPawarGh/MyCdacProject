import { Customer } from "./customer"

export class Vehicle {
    vehicleId:number
    vehicleCompany:string
    model:string
    numberPlate:string
    customer:Customer
    constructor(){}
}
