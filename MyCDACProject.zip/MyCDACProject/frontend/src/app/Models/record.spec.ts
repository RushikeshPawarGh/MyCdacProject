import { Record } from './record';

describe('Record', () => {
  it('should create an instance', () => {
    expect(new Record()).toBeTruthy();
  });
});
