export class Record {
    recordId:number
    billingDate:Date
    bookingDate:Date
    problemDescription:string
    status:String
    totalCost:number
}
